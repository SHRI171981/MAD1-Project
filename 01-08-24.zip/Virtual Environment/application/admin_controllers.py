from flask import Flask, render_template,redirect,url_for,flash,request
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy import func
from application.models import*
from application.home_controllers import login_required

@app.route('/admin/home/<admin_ID>',methods=["GET"])
@login_required(role='admin')
def admin_home(admin_ID):
    admin=db.session.query(Admin).filter(Admin.AdminID==admin_ID).one()
    return render_template("Admin_home.html",admin=admin)

@app.route('/admin/profile/<admin_ID>',methods=['GET'])
@login_required(role='admin')
def admin_profile(admin_ID):
    admin=db.session.query(Admin).filter(Admin.AdminID==admin_ID).one()
    return render_template('Admin_profile.html',admin=admin)

@app.route('/admin/profile_picture/edit/<admin_ID>',methods=['GET','POST'])
@login_required(role='admin')
def admin_profile_edit(admin_ID):
    admin=db.session.query(Admin).filter(Admin.AdminID==admin_ID).one()
    if request.method=='GET':
        return render_template('Admin_profile_edit.html',admin=admin)
    
@app.route('/admin/campaigns/<admin_ID>',methods=['GET'])
@login_required(role='admin')
def admin_campaigns(admin_ID):
    from datetime import datetime
    today=datetime.today()
    active_campaigns=(db.session.query(Campaign,Influencer,Sponsor)
                      .filter(Campaign.EndDate>=today)
                      .join(Influencer,Campaign.InfluencerID==Influencer.InfluencerID)
                      .join(Sponsor,Campaign.SponsorID==Sponsor.SponsorID)
                      .order_by(Campaign.EndDate)
                      .all())
    completed_campaigns=(db.session.query(Campaign,Influencer,Sponsor)
                      .filter(Campaign.EndDate<today)
                      .join(Influencer,Campaign.InfluencerID==Influencer.InfluencerID)
                      .join(Sponsor,Campaign.SponsorID==Sponsor.SponsorID)
                      .order_by(Campaign.EndDate.desc())
                      .all())    
    return render_template('Admin_campaigns.html',active=active_campaigns,completed=completed_campaigns,admin_ID=admin_ID)

@app.route('/admin/campaign/campaign_details/<admin_ID>/<campaign_ID>',methods=['GET'])
@login_required(role='admin')
def admin_campaign_details(admin_ID,campaign_ID):
    (camp,inf,spon)=(db.session.query(Campaign,Influencer,Sponsor)
                      .filter(Campaign.CampaignID==campaign_ID)
                      .join(Influencer,Campaign.InfluencerID==Influencer.InfluencerID)
                      .join(Sponsor,Campaign.SponsorID==Sponsor.SponsorID)
                      .one())
    return render_template('Admin_campaign_details.html',camp=camp,spon=spon,inf=inf,admin_ID=admin_ID)


@app.route('/admin/sponsors/<admin_ID>',methods=['GET'])
@login_required(role='admin')
def admin_sponsors(admin_ID):
    sponsors=(db.session.query(Sponsor,func.sum(Campaign.Budget),func.sum(Campaign.Outreach),func.count(Campaign.CampaignID))
                .join(Campaign,Campaign.SponsorID==Sponsor.SponsorID)
                .group_by(Sponsor.SponsorID)
                .order_by(Sponsor.JoiningDate).all())
    return render_template('Admin_sponsors.html',admin_ID=admin_ID,sponsors=sponsors)

@app.route('/admin/sponsor/sponsor_details/<admin_ID>/<sponsor_ID>',methods=['GET'])
@login_required(role='admin')
def admin_sponsor_details(admin_ID,sponsor_ID):
    sponsor_campaign=(db.session.query(Sponsor,func.count(Campaign.CampaignID))
                      .filter(Sponsor.SponsorID==sponsor_ID)
                      .join(Campaign,Campaign.SponsorID==Sponsor.SponsorID)
                      .one())
    (spon,campaigns)=sponsor_campaign
    return render_template('Admin_sponsor_details.html',admin_ID=admin_ID,spon=spon,campaigns=campaigns)

@app.route('/admin/sponsor/sponsor_campaigns/<admin_ID>/<sponsor_ID>',methods=['GET'])
@login_required(role='admin')
def admin_sponsor_campaigns(admin_ID,sponsor_ID):
    from datetime import datetime
    today=datetime.today()
    active=(db.session.query(Sponsor,Influencer,Campaign)
            .filter(Sponsor.SponsorID==sponsor_ID)
            .join(Campaign,Campaign.SponsorID==Sponsor.SponsorID)
            .join(Influencer,Campaign.InfluencerID==Influencer.InfluencerID)
            .filter(Campaign.EndDate>=today)
            .order_by(Campaign.EndDate)
            .all())
    completed=(db.session.query(Sponsor,Influencer,Campaign)
            .filter(Sponsor.SponsorID==sponsor_ID)
            .join(Campaign,Campaign.SponsorID==Sponsor.SponsorID)
            .join(Influencer,Campaign.InfluencerID==Influencer.InfluencerID)
            .filter(Campaign.EndDate<today)
            .order_by(Campaign.EndDate)
            .all())
    return render_template('Admin_sponsor_campaigns.html',admin_ID=admin_ID,sponsor_ID=sponsor_ID,active=active,completed=completed)

@app.route('/admin/influencers/<admin_ID>',methods=['GET'])
@login_required(role='admin')
def admin_influencers(admin_ID):
    influencers=(db.session.query(Influencer,func.sum(Campaign.Budget),func.count(Campaign.CampaignID))
                 .join(Campaign,Campaign.InfluencerID==Influencer.InfluencerID)
                 .group_by(Influencer.InfluencerID)
                 .order_by(Influencer.JoiningDate).all())
    return render_template('Admin_influencers.html',admin_ID=admin_ID,influencers=influencers)

@app.route('/admin/influencer/influencer_details/<admin_ID>/<influencer_ID>',methods=['GET'])
@login_required(role='admin')
def admin_influencer_details(admin_ID,influencer_ID):
    influencer_campaign=(db.session.query(Influencer,func.count(Campaign.CampaignID),func.sum(Campaign.Budget))
                      .filter(Influencer.InfluencerID==influencer_ID)
                      .join(Campaign,Campaign.InfluencerID==Influencer.InfluencerID)
                      .one())
    (inf,campaigns,earnings)=influencer_campaign
    return render_template('Admin_influencer_details.html',admin_ID=admin_ID,inf=inf,campaigns=campaigns,earnings=earnings)

@app.route('/admin/influencer/influencer_campaigns/<admin_ID>/<influencer_ID>',methods=["GET"])
@login_required(role='admin')
def admin_influencer_campaigns(admin_ID,influencer_ID):
    from datetime import datetime
    today=datetime.today()
    active=(db.session.query(Influencer,Sponsor,Campaign)
            .filter(Influencer.InfluencerID==influencer_ID)
            .join(Campaign,Campaign.InfluencerID==Influencer.InfluencerID)
            .join(Sponsor,Campaign.SponsorID==Sponsor.SponsorID)
            .filter(Campaign.EndDate>=today)
            .order_by(Campaign.EndDate)
            .all())
    completed=(db.session.query(Influencer,Sponsor,Campaign)
            .filter(Influencer.InfluencerID==influencer_ID)
            .join(Campaign,Campaign.InfluencerID==Influencer.InfluencerID)
            .join(Sponsor,Campaign.SponsorID==Sponsor.SponsorID)
            .filter(Campaign.EndDate<today)
            .order_by(Campaign.EndDate)
            .all())
    return render_template('Admin_influencer_campaigns.html',admin_ID=admin_ID,active=active,completed=completed,influencer_ID=influencer_ID)

@app.route('/admin/trial')
def admin_trial():
    influencers=(db.session.query(Influencer,func.sum(Campaign.Budget),func.count(Campaign.CampaignID))
                 .join(Campaign,Campaign.InfluencerID==Influencer.InfluencerID)
                 .group_by(Influencer.InfluencerID)
                 .order_by(Influencer.JoiningDate).all())
    
    final=[(result[0].Name,result[1],result[2]) for result in influencers]
    return(final)