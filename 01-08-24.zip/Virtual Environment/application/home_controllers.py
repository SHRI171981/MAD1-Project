from flask import Flask, render_template,redirect,url_for,flash,request,session,abort
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import check_password_hash
from application.models import*
from functools import wraps


def login_user(user, user_type):
    if user_type == 'admin':
        user_id = user.AdminID
    elif user_type == 'sponsor':
        user_id = user.SponsorID
    elif user_type == 'influencer':
        user_id = user.InfluencerID
    else:
        user_id = None
    session['user_id'] = user_id
    session['user_type'] = user_type

def get_user_by_type(user_type, username):
    if user_type == 'admin':
        return Admin.query.filter_by(Name=username).first()
    elif user_type == 'sponsor':
        return Sponsor.query.filter_by(Name=username).first()
    elif user_type == 'influencer':
        return Influencer.query.filter_by(Name=username).first()
    return None

#forbidden
@app.errorhandler(403)
def forbidden_error(error):
    return render_template('Home_Error.html',message="You are not authorized to access this page"), 403

#Login Manager
def login_required(role=None):
    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            if 'user_id' not in session:
                flash('You need to log in to access this page.')
                return redirect(url_for('login'))
            if role and session.get('user_type') != role:
                abort(403)
            return f(*args, **kwargs)
        return decorated_function
    return decorator

@app.route('/login', methods=['GET', 'POST'])
def login():
    error=None
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        user_type = request.form['role']

        user = get_user_by_type(user_type, username)

        if user and (user.Password==password):
            login_user(user, user_type)
            if user_type == 'admin':
                return redirect(f'/admin/home/{user.AdminID}')
            elif user_type == 'sponsor':
                return redirect(f'/sponsor/home/{user.SponsorID}')
            elif user_type == 'influencer':
                return redirect(f'/influencer/home/{user.InfluencerID}')
        else:
            error='Invalid Username or Password'

    return render_template('Home_Login.html',error=error)

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('login'))